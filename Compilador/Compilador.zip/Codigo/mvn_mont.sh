java -cp MLR.jar montador.MvnAsm mvn_test2.asm
java -cp MLR.jar relocator.MvnRelocator mvn_test2.mvn 0000 000
java -Dfile.encoding=cp850 -jar mvn.jar
