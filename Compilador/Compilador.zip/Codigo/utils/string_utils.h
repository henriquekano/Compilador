#ifndef STRING_UTILS_H_INCLUDED
#define STRING_UTILS_H_INCLUDED

#include "bool.h"

bool isDigit(char *string);
bool startsWith(const char *pre, const char *str);
char * strip(char *s);

#endif