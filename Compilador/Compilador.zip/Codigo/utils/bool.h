#ifndef BOOL_H_DEFINED
#define BOOL_H_DEFINED
typedef enum { FALSE, TRUE } bool;
#endif