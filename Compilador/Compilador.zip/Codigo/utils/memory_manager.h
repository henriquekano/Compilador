#ifndef LIST_H_DEFINED
#define LIST_H_DEFINED

void *mallocae(int memory_quantity);

#endif