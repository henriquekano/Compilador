#ifndef FILE_MANAGER_H_INCLUDED
#define FILE_MANAGER_H_INCLUDED

#include <stdio.h>

void write(FILE *file, char *stuff);

#endif