#ifndef COMMON_INFO_H
  #define COMMON_INFO_H
  
  enum MACHINE_TYPE {
    EXPRESSAO_ARIT = 0
  };


#endif