gcc -g main.c ./utils/*.c ./lexico/*.c ./sintatico/*.c ./semantico/*.c -o a.out
gdb a.out