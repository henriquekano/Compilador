gcc -Wall main.c ./utils/*.c ./lexico/*.c ./sintatico/*.c ./semantico/*.c
a
